$(document).ready(function() {
    
    /* For the sticky navigation */
    $('.js--section-skills').waypoint(function(direction) {
        if (direction == "down") {
            $('nav').addClass('sticky');
        } else {
            $('nav').removeClass('sticky');
        }
    },{
        offset: '65px;'
    })
    
     /* Scroll on buttons */
    $('.js--scroll-to-portfolio').click(function(){
        $('html, body').animate({scrollTop: $('.js--section-portfolio').offset().top}, 2000);
    })
     $('.js--scroll-to-about').click(function(){
        $('html, body').animate({scrollTop: $('.js--section-skills').offset().top}, 2000);
    })
    
   /* Navigation Scroll */
    /*
    $(function() {
        $('a[href*=#]:not([href=#])').click(function() {
            if (location.pathname.replace(/^\//,'') == this.pathname.replace(/^\//,'') && location.hostname == this.hostname) {
                var target = $(this.hash);
                target = target.length ? target : $('[name=' + this.hash.slice(1) +']');
                if (target.length) {
                    $('html,body').animate({
                        scrollTop: target.offset().top
                    }, 2000);
                    return false;
                }
            }
        });
    });
    */
    // Select all links with hashes
    $(function() {
      $('a[href*="#"]:not([href="#"])').click(function() {
        if (location.pathname.replace(/^\//,'') == this.pathname.replace(/^\//,'') && location.hostname == this.hostname) {
          var target = $(this.hash);
          target = target.length ? target : $('[name=' + this.hash.slice(1) +']');
          if (target.length) {
            $('html, body').animate({
              scrollTop: target.offset().top
            }, 1000);
            return false;
          }
        }
      });
    });
    
    /* Animation Scrolling */
    $('.js--wp-1').waypoint(function(direction) {
        $('.js--wp-1').addClass('animated fadeIn');
    }, {
        offset: '50%'
    })
    
    /* Stay blurred */
    
    
    
    
    
    
});